#include "json/json.h"

Json::Value s_test; 
int main()
{
   s_test["aaa"] = 1;
   return 0;
}


