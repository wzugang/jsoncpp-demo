#include "json/json.h"

class CA
{
public:
    CA();
    virtual ~CA();

protected:
private:
};

CA::CA()
{

}

CA::~CA()
{
    Json::FastWriter writer;

    Json::Value item;
    item[0u] = 0;
    item[1u] = "kuan"; // 到这行时崩溃
}

CA a;

int main()
{

}

